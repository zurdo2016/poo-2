package com.ug.escuela.dominio;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "materias")
public class Materias {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer materiaId;
    private String codigo;
    private String nombre;
    @OneToMany(mappedBy = "materia_id")
	@JsonBackReference
    private List<Pensum> pensumList;
	public Integer getMateriaId() {
		return materiaId;
		
	}
	public Materias() {
	}
	
	public void setMateriaId(Integer materiaId) {
		this.materiaId = materiaId;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Pensum> getPensumList() {
		return pensumList;
	}
	public void setPensumList(List<Pensum> pensumList) {
		this.pensumList = pensumList;
	}

    

}
