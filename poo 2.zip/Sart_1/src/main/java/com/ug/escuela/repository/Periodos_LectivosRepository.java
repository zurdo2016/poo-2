package com.ug.escuela.repository;

public interface Periodos_LectivosRepository {

}
