package com.ug.escuela.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ug.escuela.dominio.Estudiantes;
import com.ug.escuela.dominio.Pensum;



public interface EstudiantesRepository extends CrudRepository<Estudiantes, Integer> {


	public List<Pensum> findByLiteral (int arg);
	public List<Pensum> findByLiteralAndDescripcion (int arg && varchar );
	public List<Pensum> findByLiteralOrDescripcion ( );	
	
	
}
