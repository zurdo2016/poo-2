package com.ug.escuela.repository;

import org.springframework.data.repository.CrudRepository;

import com.ug.escuela.dominio.Materias;


public interface MateriasRepository extends CrudRepository<Materias, Integer>{

}
