package com.ug.escuela.dominio;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity(name="estudiantes")
public class Estudiantes {
	  private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)

	    private Integer estudianteId;
	    private String descripcion;
	    @OneToMany(mappedBy = "estudiante_Id")
	    private List<Pensum> pensumList;
		public Integer getEstudianteId() {
			return estudianteId;
			
		}
		public void setEstudianteId(Integer estudianteId) {
			this.estudianteId = estudianteId;
		}
		public String getDescripcion() {
			return descripcion;
		}
		public void setDescripcion(String descripcion) {
			this.descripcion = descripcion;
		}
		public List<Pensum> getPensumList() {
			return pensumList;
		}
		public void setPensumList(List<Pensum> pensumList) {
			this.pensumList = pensumList;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
	    
	    
}
