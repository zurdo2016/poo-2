package com.ug.escuela;

public @interface SpringBootApplication {

}
