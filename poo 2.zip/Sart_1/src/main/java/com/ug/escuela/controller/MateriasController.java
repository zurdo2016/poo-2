package com.ug.escuela.controller;

public class MateriasController {

}
