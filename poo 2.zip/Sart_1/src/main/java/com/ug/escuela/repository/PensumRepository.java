package com.ug.escuela.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.ug.escuela.dominio.Pensum;


public interface PensumRepository extends CrudRepository<Pensum, Integer> {

	@Query("select new com.ug.encuesta.dominio.Pensum(g.pensum_id,g.materia_id,g.periodo_id,g.estudiante_id,g.grupo_id) from pensum g")
	public List<Pensum> getGrupo();

}
