package com.ug.escuela.dominio;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "periodos_lectivos")
public class Periodos_Lectivos {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)

	    private Integer periodoId;

	    private String descripcion;
	    @OneToMany(mappedBy = "periodoId")
		@JsonBackReference
		
	    private List<Pensum> pensumList;
		public Integer getPeriodoId() {
			return periodoId;
		}
		public void setPeriodoId(Integer periodoId) {
			this.periodoId = periodoId;
		}
		public String getDescripcion() {
			return descripcion;
		}
		public void setDescripcion(String descripcion) {
			this.descripcion = descripcion;
		}
		public List<Pensum> getPensumList() {
			return pensumList;
		}
		public void setPensumList(List<Pensum> pensumList) {
			this.pensumList = pensumList;
		}
	    
	    
}
