package com.ug.escuela.dominio;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity(name="pensum")
public class Pensum {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer pensumId;
	    private Integer grupoId;
	    @JoinColumn(name = "estudiante_id", referencedColumnName = "estudiante_id")
		@JsonBackReference
	    @ManyToOne
	    private Estudiantes estudianteId;
	    @JoinColumn(name = "materia_id", referencedColumnName = "materia_id")
		@JsonBackReference
	    @ManyToOne
	    private Materias materiaId;
	    @JoinColumn(name = "periodo_id", referencedColumnName = "periodo_id")
		@JsonBackReference
	    @ManyToOne
	    private Periodos_Lectivos periodoId;
	    

		public Pensum() {
		}
		
		public Integer getPensumId() {
			return pensumId;
		}
		public void setPensumId(Integer pensumId) {
			this.pensumId = pensumId;
		}
		
		public Integer getGrupoId() {
			return grupoId;
		}
		public void setGrupoId(Integer grupoId) {
			this.grupoId = grupoId;
		}
		public Estudiantes getEstudianteId() {
			return estudianteId;
		}
		public void setEstudianteId(Estudiantes estudianteId) {
			this.estudianteId = estudianteId;
		}
		public Materias getMateriaId() {
			return materiaId;
		}
		public void setMateriaId(Materias materiaId) {
			this.materiaId = materiaId;
		}
		public Periodos_Lectivos getPeriodoId() {
			return periodoId;
		}
		public void setPeriodoId(Periodos_Lectivos periodoId) {
			this.periodoId = periodoId;
		}
	    
	    

}
